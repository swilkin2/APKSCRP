#!/bin/bash
make -f release.mk
